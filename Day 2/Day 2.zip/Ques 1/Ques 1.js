let userinput = prompt("Enter your name: ")

console.log("Hello, " + userinput)