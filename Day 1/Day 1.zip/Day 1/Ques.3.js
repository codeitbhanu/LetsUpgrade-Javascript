// JavaScript provides different data types to hold different types of values. There are two types of data types in JavaScript.

// 1. Primitive data type
// 2. Non-primitive (reference) data type

// Below are the few commonly used listed data-type supported by JavaScript:

// String -Primitive
let message = 'Hello World!'

// Float -Primitive
let Pi = 3.14

// Int -Primitive
let distance = 5323

// Array - Non-Primitive
let subjects = ['maths', 'science', 'english']

// Object - Non-Primitive
let ranks = {
    FIRST: 'Excellent',
    SECOND: 'Good',
    THIRD: 'Average'
}


// Boolean -Primitive
let isValid = true
