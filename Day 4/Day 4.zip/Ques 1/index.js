let index = 1

do {
    const out = index % 3 == 0 && index % 5 == 0 ? "fizzbuzz" : (index % 3 == 0 ? "fizz" : (index % 5 == 0 ? "buzz" : ""))
    console.log("INDEX: " + index + " # " + out)
} while (index++ < 100)