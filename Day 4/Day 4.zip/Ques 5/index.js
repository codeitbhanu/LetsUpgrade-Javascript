let basic = parseInt(prompt("Enter salary of an employee: "))
let salesByEmp = parseInt(prompt("Enter sales amount by an employee: "))

const perc = (salesByEmp <=5000) ? 2 : ((salesByEmp <= 10000) ? 5 : ((salesByEmp <= 20000) ? 7 : 10))

const commmission = basic * perc / 100
const total = basic + commmission
console.log(`Employee commision: ${commmission} and total salary: ${total}`)