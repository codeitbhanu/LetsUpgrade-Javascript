// String Methods
let mystr = "Hello World, This is LetUpgrade JavaScript Essentials Course Day2"

// conact()
console.log(mystr.concat("... This is awesome!"))

// match()
let mystr2 = "Hello"
console.log(mystr.match("Hello"))

// slice()
let mystr3 = "Bike & Car"
console.log(mystr3.slice(0,5))

// startsWith()
let mystr4 = "This is great!"
console.log(mystr4.startsWith("This"))

// substr()
let mystr5 = "Hello World"
console.log(mystr5.substr(1, 4))

// trim()
let mystr6 = "  I have some spaces in front and end as well...   "
console.log("After Trim: >>" + mystr6.trim() + "<< End" )