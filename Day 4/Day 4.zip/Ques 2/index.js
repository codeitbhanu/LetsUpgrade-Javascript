const student = {
    name: "Helsinki",
    age: 24,
    projects: {
        diceGame: "Two player dice game using JavaScript"
    }
}

const {name, age} = student;

const {projects} = student;

console.log("Student Name: " + name + " Age: " + age + " projects " + JSON.stringify(projects))