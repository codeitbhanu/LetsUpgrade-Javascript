let fNum = parseInt(prompt("Enter first number: "))
let sNum = parseInt(prompt("Enter second number: "))

let opt = prompt("Choose operation add,sub,mult,div,sqrt,perc : ").toLowerCase().trim()

switch (opt) {
    case "add":
        console.log(fNum + sNum)
        break;
    case "sub":
        console.log(fNum - sNum)
        break;
    case "mult":
        console.log(fNum * sNum)
        break;
    case "div":
        console.log(fNum / sNum)
        break;
    case "sqrt":
        console.log(Math.sqrt(fNum))
        break;
    case "perc":
        console.log(fNum / sNum * 100)
        break;
}