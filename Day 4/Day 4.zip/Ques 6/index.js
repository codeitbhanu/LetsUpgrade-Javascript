let num = parseInt(prompt("Enter a number greater than 100: "))

while (num <= 100 && num != "") {
    num = parseInt(prompt("[Try Again] Enter a number greater than 100: "))
}

num ? console.log(`Great! You have enter a number ${num} `) : console.log(`Sorry, That you felt nothing to enter`)