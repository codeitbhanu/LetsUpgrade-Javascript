let num = prompt("Enter a number: ")

let result = num % 2 == 0 ? "even" : "odd"

console.log("The number entered is " + num + " and Number is " + result)
