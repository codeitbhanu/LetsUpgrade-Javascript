let marks = parseInt(prompt("Enter marks: "))

let grade = marks < 35 ? "Fail" : (marks < 40 ? "C" : (marks < 60 ? "B": "A"))

console.log(`Marks are ${marks} and grade is ${grade}`)