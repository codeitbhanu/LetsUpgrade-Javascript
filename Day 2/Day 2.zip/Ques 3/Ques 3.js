let age = prompt("Enter your age: ")

if (age >= 21) console.log("Can drink")
else console.log("Cannot drink")