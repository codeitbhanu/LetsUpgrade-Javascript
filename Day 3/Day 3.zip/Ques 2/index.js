let os_full = prompt("Input OS Name: ")

console.log("The OS name is " + os_full.split(" ")[0] + " and version is " + os_full.split(" ")[1])