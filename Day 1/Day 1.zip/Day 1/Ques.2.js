// var: ES2015 syntax of declaring a variable, which can be assigned and modified at later time
//      var has function scope means it cannot be used out side of function

function myFn() {
    var foo = 'hello boy!';
    
    console.log(foo); // 'hello boy!'
  }
  
console.log(foo); // ReferenceError: foo is not defined

// let: ES2016 syntax of declaring a variable, which is mutable,
//      It has block scope and cannot be used outside of a block of function as below:
for (let i = 0; i < 3; i++) {
    console.log(i);
  }
  
console.log(i); // ReferenceError: i is not defined

// const: ES2016 syntax of declaring a const, which means one a value is assigned to it, it cannot be re-assigned until the life of the const
//          But, if the assigned values is of a type of object, the internal values can be modified by using keys or indexes (in case of list type)

const myBoolean = true;
myBoolean = false; // Uncaught TypeError: Assignment to constant variable.