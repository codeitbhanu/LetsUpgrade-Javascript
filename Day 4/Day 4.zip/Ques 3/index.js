const shoppingList = [
    "milk",
    "bread",
    "spinach"
]

let shoppingBasket = [...shoppingList]

// Add chocolates
shoppingBasket.push("chocolates")

// Add beer
shoppingBasket.push("beer")

console.log("Shopping Items: " + shoppingBasket)