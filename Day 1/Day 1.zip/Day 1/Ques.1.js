// Question 1 :
// Explore and explain the various methods in console function
// Explain them
// Ex. console.log()
// console.warn().
// etc...

// Answer:

// 1. console.log 
// Description: to output console data into the console / chrome inspector, .log means any string or printable data.

console.log('Hello World, I am Rank ' + 1)

// 2. console.warn
// Description: to output warning data this to display on console, this is used when there is some information for which user is to be warned if something is not going correctly.

console.warn('Warning: There is a thunderstorm outside, please close all windows.')

// 3. console.error()
// Description: to output errorneous output on console, to catch user's attention to indicate that there is some error has induced in core, which he/she need to fix.

console.error('Error: Please enter a correct input.')

// 4. console.table()
// Description: to output an Javascript object's data in tabular format
data = {
    name: 'John',
    contact: 123456,
    gender: 'Male',
    dob: '2000-01-01'
}
console.table(data)

// 5. console.group, console.groupEnd
// Description: to group a sequence of console logs into a group to it can be identified easily, in addit

console.group('Person Data')
console.log('aaaa')
console.log('bbbb')
console.log('cccc')
console.groupEnd()

// 6. console.time() and console.timeEnd()
// Description: these can be used to calucate the execution time between 2 point of times
console.time()
i = 0
while (i < 9999) {
    i++
}
console.log('Execution completed in: ',)
console.timeEnd()