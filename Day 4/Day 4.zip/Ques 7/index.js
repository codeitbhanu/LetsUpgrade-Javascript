const getPrimeNumbers = function (limit) {
    let array = [];
    for (let number = 2; number <= limit; number++) {
        if (isPrime(number)) {
            array.push(number);
        }
    }
    console.log(array.join(','));
}

const isPrime = function (number) {
    // iterate from 2 till the current number to be tested
    for (let factor = 2; factor < number; factor++) {
        if (number % factor == 0) {
            return false;
        }
    }
    // number is prime
    return true;
}

let limit = parseInt(prompt("Enter ending range for prime number: "))

getPrimeNumbers(limit)